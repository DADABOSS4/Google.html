let bouton = true;   // bouton variable booleénne true ou false

function Changer() {
    if (bouton == true){
    document.querySelector('#zone').style.color = "white";
    document.querySelector('#zone').style.backgroundColor = "rgb(255,255,255)";
    bouton=false;
    }
    else {
    document.querySelector('#zone').style.color = "black";
    document.querySelector('#zone').style.backgroundColor = "rgb(0,0,0)";
    bouton = true;
    }
    let D = document.getElementsById("resultat");
    D.innerHTML = "Perdu !!";
}