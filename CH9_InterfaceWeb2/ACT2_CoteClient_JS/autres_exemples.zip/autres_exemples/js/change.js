let saisie;	// déclare la variable saisie


function Test() {
    saisie = formulaire.saisie.value;	// attribue ce qui est saisi  à la variable saisie
    saisie = parseFloat(saisie);		// transforme la chaîne de caractère en nombre

    if (saisie <= 10) {
    document.querySelector('#zone').style.backgroundColor = "rgb(0,0,255)";
    }
    else {
    document.querySelector('#zone').style.backgroundColor = "rgb(255,0,0)";
    }
    document.write("!!! PERDU !!!");
}
